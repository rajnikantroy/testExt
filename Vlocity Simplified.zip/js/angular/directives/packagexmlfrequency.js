app.directive("packagexmlfrequency", ['viewservice', function(viewservice) {
    return {
        restrict : "E",
        template : viewservice.packagexmlfrequency
    };
}]);